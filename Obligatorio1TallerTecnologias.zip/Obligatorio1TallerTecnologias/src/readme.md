# Taller de tecnologías 1. Universidad ORT
## Obligatorio 1 Grupo N1B

### Integrantes:
* 111111 - Manuel Pallares 
* 143403 - Sebastián Méndez 

